﻿using System.Collections;
using UnityEngine;

public class SpawnKnives : MonoBehaviour {

	public GameObject knife;

	void Start  () {
		StartCoroutine (Spawn ());
	}
		
	IEnumerator Spawn () {
		while (!Player.lose) {
			Instantiate (knife, new Vector2 (Random.Range (-2.1f, 2.8f), 6f), Quaternion.identity);
				yield return new WaitForSeconds (0.5f);
		}
	}
	
}