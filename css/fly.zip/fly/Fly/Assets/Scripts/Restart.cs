﻿using UnityEngine;
using UnityEngine.SceneManagement;

public class Restart : MonoBehaviour {

	void OnMouseDown () {
		SceneManager.LoadScene ("main");
	}
}

